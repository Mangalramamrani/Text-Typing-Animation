const dynamicText = document.querySelector('.dynamic-text');
const phrases = ['a Developer.', 'a Programmer.', 'a Designer.', 'a Coder.'];
let phraseIndex = 0;
let charIndex = 0;

function typeEffect() {
    if (charIndex < phrases[phraseIndex].length) {
        dynamicText.textContent += phrases[phraseIndex][charIndex];
        charIndex++;
        setTimeout(typeEffect, 100); // Typing speed
    } else {
        setTimeout(eraseEffect, 1000); // Pause before erasing
    }
}

function eraseEffect() {
    if (charIndex > 0) {
        dynamicText.textContent = phrases[phraseIndex].slice(0, charIndex - 1);
        charIndex--;
        setTimeout(eraseEffect, 50); // Erasing speed
    } else {
        phraseIndex = (phraseIndex + 1) % phrases.length;
        setTimeout(typeEffect, 200); // Pause before typing next phrase
    }
}

// Start the typing effect
typeEffect();
